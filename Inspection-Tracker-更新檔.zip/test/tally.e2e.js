// 「統計檔轉加扣分」端對端測試（全部虛構資料）。先啟動本機伺服器：python3 -m http.server 8765
const {chromium} = require("playwright");
const assert = require("node:assert/strict");
const path = require("node:path");
const fs = require("node:fs");
const XLSX = require("../vendor/xlsx.full.min.js");
const FX = path.join(__dirname, "fixtures");
const OUT = path.join(__dirname, "output"); fs.mkdirSync(OUT, {recursive: true});
const URL = process.env.APP_URL || "http://localhost:8765/index.html";

// 統計檔：每 3 欄一組（女生隊號、統計數、空白）。1→3 班扣 0.2；2→-3 班加 0.2；3→6 班扣 0.4；4→2 班不處理；9→3 班（名冊沒有）
const aoa = [[null, null, null, null, null, null, null, "44期公差統計表"], [],
  [1, 3, null, 3, 6, null, 9, 3], [2, -3, null, 4, 2, null, 10, null]];
const tallyPath = path.join(OUT, "tally-test.xlsx");
const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(aoa), "工作表1"); fs.writeFileSync(tallyPath, XLSX.write(wb, {type: "buffer", bookType: "xlsx"}));

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({viewport: {width: 1200, height: 900}});
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", e => errors.push(e.message));
  page.on("console", m => { if (m.type() === "error") errors.push(m.text()); });
  page.on("dialog", d => d.accept());
  const step = s => console.log("•", s);

  await page.goto(URL);
  await page.waitForSelector("#app:not([hidden])");
  await page.setInputFiles("#rosterFile", path.join(FX, "roster44.xlsx"));
  await page.waitForSelector("#rosterPending:not([hidden])");
  await page.click("#rosterSave");
  await page.waitForFunction(() => document.querySelectorAll(".cohort-card").length === 1);
  await page.setInputFiles("#pTplFile", path.join(FX, "points_template.xlsx"));
  await page.waitForFunction(() => /✓/.test(document.getElementById("pTplStatus").textContent));

  step("內務 → 統計檔轉加扣分：選統計檔");
  await page.click("#tabBtn-dorm");
  await page.click('[data-sub="tally"]');
  await page.setInputFiles("#tFile", tallyPath);
  await page.waitForSelector("#tPreview:not([hidden])");
  assert.match(await page.textContent("#tFileName"), /讀到 5 人/);

  step("選事蹟說明 → 預覽結果");
  const pick = async (key, prefix) => {
    const cats = await page.$$eval(`#tCat-${key} option`, os => os.map(o => o.textContent).filter(t => t && t !== "請選擇"));
    const cat = cats.find(c => c.startsWith(prefix)); assert.ok(cat, prefix + " 歸類不存在");
    await page.selectOption(`#tCat-${key}`, cat);
    const reasons = await page.$$eval(`#tReason-${key} option`, os => os.map(o => o.textContent).filter(t => t && t !== "請選擇"));
    await page.selectOption(`#tReason-${key}`, reasons[0]);
    return {cat, reason: reasons[0]};
  };
  const mm = await pick("minus", "不良"), pp = await pick("plus", "優良");
  const rows = await page.$$eval("#tTbl tbody tr", trs => trs.map(t => t.innerText.replace(/\s+/g, " ").trim()));
  assert.equal(rows.length, 4, "應有 4 列（1、2、3、9；4 班數不足不列）");
  assert.match(rows[0], /001 .*王小美 3 扣分 0\.2/);
  assert.match(rows[1], /002 .*林小華 -3 加分 0\.2/);
  assert.match(rows[2], /003 .*陳小玉 6 扣分 0\.4/);
  assert.match(rows[3], /009 .*名冊無此編號/);
  assert.match(await page.textContent("#tSummary"), /扣分 2 人（0\.6 分）、加分 1 人（0\.2 分）/);
  assert.match(await page.textContent("#tWarn"), /009（3）/);

  step("取消勾選一位 → 轉入加扣分");
  await page.uncheck('[data-toff="3"]');
  assert.match(await page.textContent("#tApply"), /2 筆/);
  await page.fill("#tDate", "2026-10-28");
  await page.click("#tApply");
  assert.match(await page.textContent("#tMsg"), /新增 2 筆/);
  // 再轉一次同一天 → 取代而不是重複
  await page.click("#tApply");
  assert.match(await page.textContent("#tMsg"), /取代原本 2 筆/);

  step("結轉下月：下載後每人只剩不足一次的班數");
  await page.evaluate(() => { window.__names = []; document.addEventListener("click", e => { const a = e.target.closest && e.target.closest("a[download]"); if (a) window.__names.push(a.download); }, true); });
  const [cdl] = await Promise.all([page.waitForEvent("download"), page.click("#tCarry")]);
  const cpath = path.join(OUT, "carry-test.xlsx"); await cdl.saveAs(cpath);
  assert.match((await page.evaluate(() => window.__names))[0], /^內務統計_結轉下月_\d{8}\.xlsx$/);
  const cw = XLSX.read(fs.readFileSync(cpath), {type: "buffer"}), cg = XLSX.utils.sheet_to_json(cw.Sheets[cw.SheetNames[0]], {header: 1, defval: null});
  // 原本 [1,3] [4,6] [9,3] / [2,-3] [3,2]… → 3→0、6→0、3→0、-3→0、2→2；標題與空白欄位保持原樣
  assert.deepEqual(cg[2], [1, 0, null, 3, 0, null, 9, 0]);
  assert.deepEqual(cg[3], [2, 0, null, 4, 2, null, 10, null]);
  assert.equal(cg[0][7], "44期公差統計表");

  step("加扣分分頁：確認紀錄");
  await page.click("#tabBtn-points");
  await page.waitForFunction(() => document.querySelectorAll("#pRecords tr").length === 2);
  const recs = await page.$$eval("#pRecords tr", trs => trs.map(t => t.innerText.replace(/\s+/g, " ")));
  assert.ok(recs.some(r => /王小美/.test(r) && /10\/28 內務統計 3班/.test(r) && /扣分/.test(r) && /0\.2/.test(r)), recs.join("\n"));
  assert.ok(recs.some(r => /林小華/.test(r) && /內務統計 -3班/.test(r) && /加分/.test(r)), recs.join("\n"));
  assert.ok(!recs.some(r => /陳小玉/.test(r)), "取消勾選的人不應轉入");

  step("重新整理後設定仍在");
  await page.reload(); await page.waitForSelector("#app:not([hidden])");
  await page.click("#tabBtn-dorm"); await page.click('[data-sub="tally"]');
  assert.equal(await page.inputValue("#tCat-minus"), mm.cat);
  assert.equal(await page.inputValue("#tReason-plus"), pp.reason);
  assert.deepEqual(errors, [], "不應有錯誤：" + errors.join("; "));
  console.log("✓ 全部通過");
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
